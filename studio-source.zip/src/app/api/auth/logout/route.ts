import { appUrl,incomingUrl } from '@/studio/origin';
import { NextResponse } from 'next/server';
import { cookieOptions, sameOrigin, SESSION_COOKIE } from '@/studio/auth';
export async function POST(request: Request) {
 if(!sameOrigin(request.headers.get('origin'),incomingUrl(request)) || request.headers.get('sec-fetch-site')==='cross-site') return NextResponse.json({error:'Invalid request'},{status:403});
 const response=NextResponse.redirect(appUrl('/login',incomingUrl(request)),303);
 response.cookies.set(SESSION_COOKIE,'',{...cookieOptions(request.url),maxAge:0});
 response.headers.set('Cache-Control','no-store'); return response;
}
