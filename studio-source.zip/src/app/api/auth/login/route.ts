import { appUrl,incomingUrl } from '@/studio/origin';
import { NextResponse } from 'next/server';
import { authMode, boundedBody, checkAttempt, clearAttempts, clientKey, cookieOptions, createSession, passwordMatches, recordFailure, sameOrigin, SESSION_COOKIE } from '@/studio/auth';
export const runtime='nodejs';
export async function POST(request: Request) {
 const headers={'Cache-Control':'no-store'};
 if(!sameOrigin(request.headers.get('origin'),incomingUrl(request)) || request.headers.get('sec-fetch-site')==='cross-site') return NextResponse.json({error:'Invalid request'},{status:403,headers});
 const mode=authMode(request.url);
 if(mode==='unavailable') return NextResponse.json({error:'Studio access is not configured'},{status:503,headers});
 const key=clientKey(request.headers);
 if(!checkAttempt(key)) return NextResponse.json({error:'Please try again later'},{status:429,headers:{...headers,'Retry-After':'900'}});
 let password='';
 try {
  if(!request.headers.get('content-type')?.startsWith('application/x-www-form-urlencoded')) throw new Error();
  const form=new URLSearchParams(await boundedBody(request));
  if(form.getAll('password').length!==1) throw new Error();
  password=form.get('password') || '';
 } catch {return NextResponse.json({error:'Invalid request'},{status:400,headers});}
 // Reading bodies yields; recheck before the synchronous password check so concurrent failures cannot overrun the cap.
 if(!checkAttempt(key)) return NextResponse.json({error:'Please try again later'},{status:429,headers:{...headers,'Retry-After':'900'}});
 if(mode!=='local' && !passwordMatches(password,process.env.SHIVALI_AUTH_PASSWORD!)) {
  recordFailure(key); return NextResponse.json({error:'Unable to sign in'},{status:401,headers});
 }
 clearAttempts(key);
 const response=NextResponse.redirect(appUrl('/',incomingUrl(request)),303);
 response.headers.set('Cache-Control','no-store');
 if(mode==='protected') response.cookies.set(SESSION_COOKIE,createSession(process.env.SHIVALI_SESSION_SECRET!),cookieOptions(request.url));
 return response;
}
