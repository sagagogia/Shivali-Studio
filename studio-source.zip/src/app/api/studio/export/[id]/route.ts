import { sameOrigin } from '../../../../../studio/http.ts';
import { exportCampaign } from '../../../../../studio/core.ts';
export const runtime='nodejs';
export async function GET(request:Request,{params}:{params:Promise<{id:string}>}){try{if(!sameOrigin(request))return Response.json({error:'Cross-origin request rejected'},{status:403});const cid=(await params).id;return Response.json(exportCampaign(cid),{headers:{'Content-Disposition':`attachment; filename="campaign-package.json"`,'Cache-Control':'no-store'}});}catch{return Response.json({error:'Final render approval required before export'},{status:409});}}
