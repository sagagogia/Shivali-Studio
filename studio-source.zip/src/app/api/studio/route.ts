import { sameOrigin } from '../../../studio/http.ts';
import { boundedJson } from '../../../studio/http.ts';
import { getSnapshot,applyAction } from '../../../studio/core.ts';
export const runtime='nodejs';
export const dynamic='force-dynamic';
export async function GET(){return Response.json(getSnapshot());}
export async function POST(request:Request){try{if(!sameOrigin(request))return Response.json({error:'Cross-origin request rejected'},{status:403});return Response.json(applyAction(await boundedJson(request) as import('../../../studio/types.ts').Action));}catch(error){return Response.json({error:error instanceof Error&& !/SQLITE|ENOENT|EACCES/.test(error.message)?error.message:'Unable to update studio'},{status:400});}}
