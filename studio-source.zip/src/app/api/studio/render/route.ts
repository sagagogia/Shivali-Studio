import { after } from 'next/server';
import { join } from 'node:path';
import { getSnapshot,getCampaign,createJob,updateJob,readAsset,registerRenderedAsset } from '../../../../studio/core.ts';
import { dataDir } from '../../../../studio/store.ts';
import { renderPreview } from '../../../../studio/render.ts';
import { previewOverlays, photoRoles } from '../../../../studio/workflow.ts';
import { sameOrigin,boundedJson,safeError } from '../../../../studio/http.ts';
export const runtime='nodejs';
export const dynamic='force-dynamic';
export async function POST(request:Request){
 if(!sameOrigin(request))return Response.json({error:'Cross-origin request rejected'},{status:403});
 try {
  const body=await boundedJson(request);if(typeof body.campaignId!=='string')throw new Error('Campaign required');
  const c=getCampaign(body.campaignId);if(body.version!==c.version)throw new Error('Campaign changed. Review the current version first.');
  const images=getSnapshot().assets.filter(a=>a.campaignId===c.id&&a.kind==='image'&&!a.superseded&&a.qa?.garmentAccuracy==='pass');
  if(!images.length)throw new Error('Upload and review at least one campaign image first. A mannequin reference alone is not an approved model image.');
  if(images.length>12)throw new Error('Select a campaign with at most 12 approved images for this preview.');
  const music=getSnapshot().assets.filter(a=>a.campaignId===c.id&&a.kind==='music'&&a.qa?.technicalPassed&&a.qa?.garmentAccuracy==='pass'&&a.qa?.licenseConfirmed).at(-1);
  if(c.workflow==='guided')images.sort((a,b)=>photoRoles.indexOf(a.shotRole!)-photoRoles.indexOf(b.shotRole!));
  const packet=images.map(a=>({id:a.id,path:readAsset(a.id).path,sha256:a.sha256}));
  const job=createJob(c.id,'render');
  after(async()=>{
   try { updateJob(job.id,{status:'running',message:'OpenMontage is composing a source-image preview.'});
    const result=await renderPreview({campaignId:c.id,version:c.version,title:c.title,images:packet,overlays:c.workflow==='guided'?previewOverlays(c.plan):[],...(music?{music:{id:music.id,path:readAsset(music.id).path,sha256:music.sha256,licenseConfirmed:true}}:{}),outputDir:join(dataDir(),'renders',job.id)});
    const asset=registerRenderedAsset(c.id,result.outputPath,c.version);
    updateJob(job.id,{status:'completed',message:'Verified 27-second source-image preview. Review before export.',outputAssetId:asset.id});
   }catch(error){updateJob(job.id,{status:'failed',message:error instanceof Error&&!/\/workspace|\/home/.test(error.message)?error.message:'Local preview failed. Check the worker configuration.'});}
  });
  return Response.json({job,snapshot:getSnapshot()},{status:202});
 }catch(error){return safeError(error);}
}
