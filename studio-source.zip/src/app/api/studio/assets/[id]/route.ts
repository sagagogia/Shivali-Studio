import { readFile } from 'node:fs/promises';
import { readAsset } from '../../../../../studio/core.ts';
export const runtime='nodejs';
export async function GET(_request:Request,{params}:{params:Promise<{id:string}>}){try{const {asset,path}=readAsset((await params).id);return new Response(await readFile(path),{headers:{'Content-Type':asset.mimeType,'Content-Length':String(asset.bytes),'Cache-Control':'private, no-store','X-Content-Type-Options':'nosniff'}});}catch{return Response.json({error:'Asset not found'},{status:404});}}
