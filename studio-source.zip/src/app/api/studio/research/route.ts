import {after} from 'next/server';
import {randomUUID} from 'node:crypto';
import {readFile} from 'node:fs/promises';
import {analyseGarment,getOpenAIStatus,AIError,RESEARCH_ESTIMATE_CENTS} from '../../../../studio/openai.ts';
import {getSnapshot,getCampaign,readAsset,createPaidJob,validatePaidJob,updateJob,completeResearch,reconcileBudget,releaseBudget} from '../../../../studio/core.ts';
import {verifyMedia} from '../../../../studio/technical.ts';
import {sameOrigin,boundedJson,safeError} from '../../../../studio/http.ts';
export const runtime='nodejs';export const dynamic='force-dynamic';
export async function POST(request:Request){
 if(!sameOrigin(request))return Response.json({error:'Cross-origin request rejected'},{status:403});
 if(!getOpenAIStatus().enabled)return Response.json({error:'OpenAI research is not enabled. Configure the key and approve the paid-generation switch first. No request was sent.'},{status:409});
 try{const body=await boundedJson(request);if(body.approved!==true||typeof body.campaignId!=='string')throw Error('Campaign and explicit research approval required');const c=getCampaign(body.campaignId);if(c.version!==body.version)throw Error('Campaign changed; review current references first');const s=getSnapshot(),g=s.garments.find(g=>g.id===c.garmentId)!;const assets=s.assets.filter(a=>a.garmentId===g.id&&a.kind==='reference');if(!assets.length||assets.length>14)throw Error('Provide 1–14 original photographs for research');for(const a of assets)verifyMedia(readAsset(a.id).path,a.mimeType,a.sha256);const references=await Promise.all(assets.map(async a=>({mimeType:a.mimeType,bytes:await readFile(readAsset(a.id).path)})));if(references.reduce((n,r)=>n+r.bytes.length,0)>25*1024*1024)throw Error('Research references exceed 25 MB combined');const operation=randomUUID(),job=createPaidJob(c.id,c.version,RESEARCH_ESTIMATE_CENTS,operation,'research');
 after(async()=>{let attempted=false;try{validatePaidJob(job.id);updateJob(job.id,{status:'running',message:'Analysing actual garment photographs and researching public editorial sources.'});attempted=true;const result=await analyseGarment({specifications:g,references,approved:true,onRequestId:id=>{updateJob(job.id,{status:'running',providerRequestIds:[id],providerRequestId:id});}});reconcileBudget(c.id,operation,RESEARCH_ESTIMATE_CENTS);completeResearch(job.id,result);}catch(e){if(!attempted||(e instanceof AIError&&!e.submitted))releaseBudget(c.id,operation);updateJob(job.id,{status:'failed',message:e instanceof AIError?e.message:'Research could not be saved because the campaign changed. Review the job before retrying.'});}});
 return Response.json({job,snapshot:getSnapshot()},{status:202});}catch(e){return safeError(e);}
}
