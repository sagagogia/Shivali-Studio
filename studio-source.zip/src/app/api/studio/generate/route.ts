import { after } from 'next/server';
import { randomUUID,createHash } from 'node:crypto';
import { readFile,rm } from 'node:fs/promises';
import { join } from 'node:path';
import { getSnapshot,getCampaign,createPaidJob,validatePaidJob,updateJob,readAsset,reconcileBudget,releaseBudget,saveUpload } from '../../../../studio/core.ts';
import { dataDir } from '../../../../studio/store.ts';
import { buildGarmentPrompt,buildFixedModelPrompt,ProviderError } from '../../../../studio/provider.ts';
import { imageServiceStatus,generateStudioImage } from '../../../../studio/image-service.ts';
import { verifyMedia } from '../../../../studio/technical.ts';
import { AIError,auditGeneratedImage,type AutomatedPhotoReview } from '../../../../studio/openai.ts';
import { photoRoles } from '../../../../studio/workflow.ts';
import type { ShotRole } from '../../../../studio/types.ts';
import { sameOrigin,boundedJson,safeError } from '../../../../studio/http.ts';
export const runtime='nodejs';
export const dynamic='force-dynamic';
export async function POST(request:Request){
 if(!sameOrigin(request))return Response.json({error:'Cross-origin request rejected'},{status:403});
 const provider=imageServiceStatus();
 if(!provider.enabled)return Response.json({error:'Paid generation is disabled. No request was submitted. Check the OpenAI key setting and enable paid generation after approving a budget.'},{status:409});
 try {
  const body=await boundedJson(request);if(body.approved!==true)throw new Error('Explicit per-call approval is required.');
  if(typeof body.campaignId!=='string')throw new Error('Campaign required');const c=getCampaign(body.campaignId);
  if(body.version!==c.version)throw new Error('Campaign changed. Review the current version first.');
  const snapshot=getSnapshot();
  if(snapshot.approvals.filter(a=>a.campaignId===c.id&&a.version===c.version&&a.gate==='concept').at(-1)?.decision!=='approved')throw new Error('Approve the current concept before generation.');
  const garment=snapshot.garments.find(g=>g.id===c.garmentId)!;
  const model=snapshot.models?.find(m=>m.id===c.modelId);
  const role=body.shotRole as ShotRole;
  const rejected=snapshot.assets.find(a=>a.campaignId===c.id&&a.kind==='image'&&!a.superseded&&a.shotRole===role&&(a.qa?.garmentAccuracy==='fail'||a.aiReview?.status==='fail'));
  if(!model||!photoRoles.includes(role))throw new Error('Select an approved fixed model and one of the three shot roles first.');
  const identityRefs=(c.workflow==='guided'||!!c.modelId)?model!.referenceIds.map(id=>snapshot.assets.find(a=>a.id===id&&a.kind==='model')).filter((a):a is NonNullable<typeof a>=>!!a):[];
  if((c.workflow==='guided'||!!c.modelId)&&identityRefs.length!==model!.referenceIds.length)throw new Error('Model identity references are incomplete.');
  const refs=snapshot.assets.filter(a=>a.garmentId===c.garmentId&&a.kind==='reference'&&a.mimeType.startsWith('image/')).slice(0,14-identityRefs.length);
  if(!refs.length)throw new Error('Upload original garment photographs first.');
  for(const asset of [...identityRefs,...refs])verifyMedia(readAsset(asset.id).path,asset.mimeType,asset.sha256);
  const references=await Promise.all([...identityRefs,...refs].map(async a=>({mimeType:a.mimeType,bytes:await readFile(readAsset(a.id).path)})));
  if(references.reduce((n,r)=>n+r.bytes.length,0)>25*1024*1024)throw new Error('Combined reference images exceed 25 MB.');
  // The durable reservation happens before a job can reach the provider.
  const operationId=randomUUID();const job=createPaidJob(c.id,c.version,provider.estimatedCents,operationId);
  const outputPath=join(dataDir(),`generated-${operationId}.png`);const requestIds:string[]=[];const remember=(id:string)=>{if(!requestIds.includes(id))requestIds.push(id);updateJob(job.id,{status:'running',providerRequestIds:[...requestIds],providerRequestId:id});};
  after(async()=>{
   let attempted=false;
   try {
    validatePaidJob(job.id);
    updateJob(job.id,{status:'running',message:'One approved reference-conditioned image request is running.'});
    attempted=true;
    const result=await generateStudioImage({prompt:(c.workflow==='guided'||!!c.modelId)?buildFixedModelPrompt(garment,c.plan?.creativeDirection||c.concept,role,identityRefs.length,model!.notes,[rejected?.qa?.notes,...(rejected?.aiReview?.issues||[])].filter(Boolean).join(' ')):buildGarmentPrompt(garment,c.concept||c.plan?.creativeDirection||'Quiet luxury studio, ivory background, soft directional light'),references,outputPath,approved:true,maxCostCents:provider.estimatedCents,onRequestId:remember});
    // Record the estimate conservatively even if later ingestion fails. Provider invoices remain authoritative.
    reconcileBudget(c.id,operationId,result.estimatedCents);
    if(getCampaign(c.id).version!==c.version)throw new Error('Campaign changed during generation. Result retained locally for recovery; current approvals were not changed.');
    const bytes=await readFile(result.outputPath);const type=bytes[0]===137?'image/png':bytes[0]===255?'image/jpeg':'image/webp';
    verifyMedia(result.outputPath,type,createHash('sha256').update(bytes).digest('hex'));
    let aiReview:AutomatedPhotoReview|undefined;
    if(provider.provider==='openai'){
     validatePaidJob(job.id);
     updateJob(job.id,{status:'running',message:'Checking generated garment details and model consistency against the originals.'});
     try{aiReview=await auditGeneratedImage({references,generated:{mimeType:type,bytes},identityCount:identityRefs.length,approved:true,onRequestId:remember});}catch{aiReview={status:'uncertain',garmentMatch:'uncertain',identityMatch:'uncertain',issues:['Automated review was unavailable. Examine all garment details and model identity before approving.'],checkedAt:new Date().toISOString()};}
    }
    const asset=saveUpload({name:'generated-model-image',type,bytes},{garmentId:c.garmentId,campaignId:c.id,kind:'image',expectedVersion:c.version,...(aiReview?{aiReview}:{}),...((c.workflow==='guided'||!!c.modelId)?{shotRole:role}:{})});
    await rm(outputPath,{force:true});
    updateJob(job.id,{status:'completed',message:`Model image ready for garment and identity review; automated findings are advisory and human approval is required. Recorded cost is an estimate ($${(result.estimatedCents/100).toFixed(2)}); verify the provider invoice.`,outputAssetId:asset.id,providerRequestId:result.providerRequestId});
   }catch(error){
    if(!attempted||((error instanceof ProviderError||error instanceof AIError)&&!error.submitted))releaseBudget(c.id,operationId);
    updateJob(job.id,{status:'failed',...((error instanceof ProviderError||error instanceof AIError)&&error.providerRequestId?{providerRequestId:error.providerRequestId}:{}),message:(error instanceof ProviderError||error instanceof AIError)&&error.submitted?'Provider outcome uncertain. Budget reservation retained; check the provider dashboard before retrying.':error instanceof Error&&!/\/workspace|\/home|FAL_KEY|Key /.test(error.message)?error.message:'Generation failed. Inspect the provider dashboard before retrying.'});
   }
  });
  return Response.json({job,snapshot:getSnapshot()},{status:202});
 }catch(error){return safeError(error);}
}
