import { after } from 'next/server';
import { randomUUID } from 'node:crypto';
import { readFile,rm } from 'node:fs/promises';
import { join } from 'node:path';
import { getSnapshot,getCampaign,createPaidJob,validatePaidJob,updateJob,readAsset,reconcileBudget,releaseBudget,saveUpload } from '../../../../studio/core.ts';
import { dataDir } from '../../../../studio/store.ts';
import { generateReferenceImage,getProviderStatus,buildGarmentPrompt,buildFixedModelPrompt,ProviderError } from '../../../../studio/provider.ts';
import { photoRoles } from '../../../../studio/workflow.ts';
import type { ShotRole } from '../../../../studio/types.ts';
import { sameOrigin,boundedJson,safeError } from '../../../../studio/http.ts';
export const runtime='nodejs';
export const dynamic='force-dynamic';
export async function POST(request:Request){
 if(!sameOrigin(request))return Response.json({error:'Cross-origin request rejected'},{status:403});
 const provider=getProviderStatus();
 if(!provider.enabled)return Response.json({error:'Paid generation is disabled. No request was submitted. Configure the provider privately and explicitly enable paid generation first.'},{status:409});
 try {
  const body=await boundedJson(request);if(body.approved!==true)throw new Error('Explicit per-call approval is required.');
  if(typeof body.campaignId!=='string')throw new Error('Campaign required');const c=getCampaign(body.campaignId);
  if(body.version!==c.version)throw new Error('Campaign changed. Review the current version first.');
  const snapshot=getSnapshot();
  if(snapshot.approvals.filter(a=>a.campaignId===c.id&&a.version===c.version&&a.gate==='concept').at(-1)?.decision!=='approved')throw new Error('Approve the current concept before generation.');
  const garment=snapshot.garments.find(g=>g.id===c.garmentId)!;
  const model=snapshot.models?.find(m=>m.id===c.modelId);
  const role=body.shotRole as ShotRole;
  const rejected=snapshot.assets.find(a=>a.campaignId===c.id&&a.kind==='image'&&!a.superseded&&a.shotRole===role&&a.qa?.garmentAccuracy==='fail');
  if(c.workflow==='guided'&&(!model||!photoRoles.includes(role)))throw new Error('Select an approved fixed model and one of the three shot roles first.');
  const identityRefs=c.workflow==='guided'?model!.referenceIds.map(id=>snapshot.assets.find(a=>a.id===id&&a.kind==='model')).filter((a):a is NonNullable<typeof a>=>!!a):[];
  if(c.workflow==='guided'&&identityRefs.length!==model!.referenceIds.length)throw new Error('Model identity references are incomplete.');
  const refs=snapshot.assets.filter(a=>a.garmentId===c.garmentId&&a.kind==='reference'&&a.mimeType.startsWith('image/')).slice(0,14-identityRefs.length);
  if(!refs.length)throw new Error('Upload original garment photographs first.');
  const references=await Promise.all([...identityRefs,...refs].map(async a=>({mimeType:a.mimeType,bytes:await readFile(readAsset(a.id).path)})));
  if(references.reduce((n,r)=>n+r.bytes.length,0)>25*1024*1024)throw new Error('Combined reference images exceed 25 MB.');
  // The durable reservation happens before a job can reach the provider.
  const operationId=randomUUID();const job=createPaidJob(c.id,c.version,provider.estimatedCents,operationId);
  const outputPath=join(dataDir(),`generated-${operationId}.png`);
  after(async()=>{
   let attempted=false;
   try {
    validatePaidJob(job.id);
    updateJob(job.id,{status:'running',message:'One approved reference-conditioned image request is running.'});
    attempted=true;
    const result=await generateReferenceImage({prompt:c.workflow==='guided'?buildFixedModelPrompt(garment,c.concept,role,identityRefs.length,model!.notes,rejected?.qa?.notes||''):buildGarmentPrompt(garment,c.concept||c.plan?.creativeDirection||'Quiet luxury studio, ivory background, soft directional light'),references,outputPath,approved:true,maxCostCents:provider.estimatedCents});
    // Record the estimate conservatively even if later ingestion fails. Provider invoices remain authoritative.
    reconcileBudget(c.id,operationId,result.estimatedCents);
    if(getCampaign(c.id).version!==c.version)throw new Error('Campaign changed during generation. Result retained locally for recovery; current approvals were not changed.');
    const bytes=await readFile(result.outputPath);const type=bytes[0]===137?'image/png':bytes[0]===255?'image/jpeg':'image/webp';
    const asset=saveUpload({name:'generated-model-image',type,bytes},{garmentId:c.garmentId,campaignId:c.id,kind:'image',expectedVersion:c.version,...(c.workflow==='guided'?{shotRole:role}:{})});
    await rm(outputPath,{force:true});
    updateJob(job.id,{status:'completed',message:`Model image ready for human garment QA. Recorded cost is an estimate ($${(result.estimatedCents/100).toFixed(2)}); verify the provider invoice.`,outputAssetId:asset.id,providerRequestId:result.providerRequestId});
   }catch(error){
    if(!attempted||(error instanceof ProviderError&&!error.submitted))releaseBudget(c.id,operationId);
    updateJob(job.id,{status:'failed',...(error instanceof ProviderError&&error.providerRequestId?{providerRequestId:error.providerRequestId}:{}),message:error instanceof ProviderError&&error.submitted?'Provider outcome uncertain. Budget reservation retained; check the provider dashboard before retrying.':error instanceof Error&&!/\/workspace|\/home|FAL_KEY|Key /.test(error.message)?error.message:'Generation failed. Inspect the provider dashboard before retrying.'});
   }
  });
  return Response.json({job,snapshot:getSnapshot()},{status:202});
 }catch(error){return safeError(error);}
}
