import Studio from '@/studio/Studio';
export default function StudioPage() { return <Studio />; }
