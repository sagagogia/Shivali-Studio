import GuidedStudio from '@/studio/GuidedStudio';
export default function StudioPage() { return <GuidedStudio />; }
