import { OpenHiggsfieldApp } from '@/openhiggsfield/openhiggsfield-app';
import '@/openhiggsfield/openhiggsfield.css';
export const dynamic = 'force-dynamic';
export default function AdvancedGenerator() {
 if(process.env.SHIVALI_ENABLE_ADVANCED_GENERATOR !== 'true') return <main style={{maxWidth:720,margin:'80px auto',padding:24,fontFamily:'system-ui'}}><h1>Advanced generator</h1><p>The original OpenHiggsfield interface is installed. Live generation is disabled for this private studio until a verified backend and credentials are configured.</p><p>The Shivali campaign workflow adds versioned approvals, private assets and budget tracking. Use that workflow for production.</p><a href="/">Return to Shivali studio</a></main>;
 return <OpenHiggsfieldApp fontClassName="" />;
}
