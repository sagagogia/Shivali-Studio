import type { Metadata } from 'next';
import LoginForm from './LoginForm';
import '@/studio/tokens.css';
import '@/studio/atelier-tokens.css';
import './login.css';
export const metadata: Metadata={title:'Sign in',robots:{index:false,follow:false}};
export const dynamic='force-dynamic';
export default function Login() {
 return <main className="studio-login">
  <aside className="login-brand-panel"><a href="/" className="login-wordmark">Shivali<span>Marketing studio</span></a><div className="login-editorial"><span className="login-brand-rule"/><h2>Every design<br/>deserves a story.</h2><p>A considered shoot.<br/>A consistent face. Your final say.</p></div><p className="login-brand-foot">Shivali Iconic Trends Pvt. Ltd.</p></aside>
  <section className="studio-login-card"><p className="studio-login-brand">Your private studio</p><h1>Welcome back.</h1><p>Sign in to bring your next collection to life.</p><LoginForm /><div className="login-access-note"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden="true"><rect x="5" y="10" width="14" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg><span>Password-protected access for your studio.</span></div><form method="post" action="/api/auth/logout" className="studio-login-logout"><button type="submit">Sign out of this browser</button></form></section>
 </main>;
}
