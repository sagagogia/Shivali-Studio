import { appUrl,incomingUrl } from './studio/origin';
import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";
import { DEVICE_COOKIE, DEVICE_COOKIE_OPTIONS, resolveDeviceId } from "./generation/device";
import { authMode, isAuthorizedRequest, isPublicPath, SESSION_COOKIE } from './studio/auth';

export function proxy(request: NextRequest) {
 const path=request.nextUrl.pathname;
 if(isPublicPath(path)) return NextResponse.next();
 if(authMode(request.url)==='unavailable') return new NextResponse('Studio access is not configured.',{status:503,headers:{'Cache-Control':'no-store','X-Robots-Tag':'noindex, nofollow'}});
 if(!isAuthorizedRequest(request.url,request.cookies.get(SESSION_COOKIE)?.value)) {
  if(path.startsWith('/api/') || request.method!=='GET') return NextResponse.json({error:'Authentication required'},{status:401,headers:{'Cache-Control':'no-store'}});
  return NextResponse.redirect(appUrl('/login',incomingUrl(request)));
 }
 const {deviceId,minted}=resolveDeviceId(request.cookies.get(DEVICE_COOKIE)?.value);
 const response=NextResponse.next();
 if(minted) response.cookies.set(DEVICE_COOKIE,deviceId,DEVICE_COOKIE_OPTIONS);
 return response;
}
export const config = { matcher: ['/:path*'] };
