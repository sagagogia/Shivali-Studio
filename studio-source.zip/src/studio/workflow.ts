import type { Snapshot, Gate, CampaignPlan } from './types.ts';

export function previewOverlays(plan:CampaignPlan|null) {
  if(!plan)return [];
  const lines=[...new Set([plan.hook,...plan.onScreenText].map(x=>x.trim()).filter(Boolean))];
  return lines.map((text,i)=>({text,startSeconds:27*i/lines.length,endSeconds:27*(i+1)/lines.length}));
}

export const steps = ['Upload design', 'Choose shoot', 'Approve photos', 'Approve video', 'Download'] as const;
export const photoRoles = ['full_pose', 'close_up', 'mood'] as const;
export function hasApproval(s: Snapshot, cid: string, gate: Gate) {
  const c = s.campaigns.find(c => c.id === cid);
  return !!c && s.approvals.filter(a => a.campaignId === cid && a.version === c.version && a.gate === gate).at(-1)?.decision === 'approved';
}
export function activePhotos(s: Snapshot, cid: string) {
  return s.assets.filter(a => a.campaignId === cid && a.kind === 'image' && !a.superseded);
}
export function getWorkflowStep(s: Snapshot, cid: string): number {
  const c = s.campaigns.find(c => c.id === cid);
  if (!c || !s.assets.some(a => a.garmentId === c.garmentId && a.kind === 'reference')) return 0;
  if (!hasApproval(s, cid, 'concept')) return 1;
  if (!hasApproval(s, cid, 'assets')) return 2;
  if (!hasApproval(s, cid, 'render') || s.assets.filter(a => a.campaignId === cid && a.kind === 'render').at(-1)?.renderVersion !== c.version) return 3;
  return 4;
}
export function researchBrief(s: Snapshot, cid: string) {
  const c = s.campaigns.find(c => c.id === cid);
  const g = s.garments.find(g => g.id === c?.garmentId);
  const refs = s.assets.filter(a => a.garmentId === g?.id && a.kind === 'reference');
  return {
    product: c?.analysis ? c.analysis.observations : g ? [`Supplied specification: ${g.designNumber} · ${g.color} · ${g.fabric}.`, `Supplied inclusions: ${[g.includesDupatta ? 'dupatta' : '', g.includesNecklace ? 'necklace' : ''].filter(Boolean).join(', ') || 'garment only'}.`, `${refs.length} original photograph${refs.length === 1 ? '' : 's'} saved.`, ...(g.notes ? [`Supplied notes: ${g.notes}`] : [])] : [],
    uncertain: c?.analysis ? c.analysis.uncertainties : ['Run garment analysis to inspect the photographs. Until then, embroidery placement, back construction and exact colour still need checking against the originals.'],
    trendStatus: c?.analysis?.sources.length ? 'completed' as const : 'not_configured' as const,
    evidence: s.sources.filter(source => source.campaignId === cid),
  };
}
