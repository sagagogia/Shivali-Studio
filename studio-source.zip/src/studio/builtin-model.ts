import {readFileSync,writeFileSync,existsSync} from 'node:fs';
import {join} from 'node:path';
import {createHash} from 'node:crypto';
import {dataDir,type State} from './store.ts';
export const BUILTIN_MODEL_ID='shivali-model-01';
const assetId='shivali-model-01-reference';
export function ensureBuiltinModel(s:State){
 if(!s.garments.length)return;
 const at=new Date().toISOString();
 if(!s.assets.some(a=>a.id===assetId)||!s.paths[assetId]||!existsSync(s.paths[assetId])){
  const bytes=readFileSync(join(process.cwd(),'assets/models/model-01.png'));
  const path=join(dataDir(),'builtin-model-01.png');
  if(!existsSync(path))writeFileSync(path,bytes,{flag:'wx',mode:0o600});
  const sha256=createHash('sha256').update(bytes).digest('hex');
  if(createHash('sha256').update(readFileSync(path)).digest('hex')!==sha256)throw new Error('Fixed model reference changed; restore approved identity before continuing');
  if(!s.assets.some(a=>a.id===assetId))s.assets.push({id:assetId,garmentId:s.garments[0].id,campaignId:null,kind:'model',filename:'Model 01 — approved ethnicwear identity.png',mimeType:'image/png',url:`/api/studio/assets/${assetId}`,sha256,bytes:bytes.length,createdAt:at,approved:true,qa:null});
  s.paths[assetId]=path;
 }
 s.models??=[];
 if(!s.models.some(m=>m.id===BUILTIN_MODEL_ID))s.models.push({id:BUILTIN_MODEL_ID,builtin:true,name:'Model 01',referenceIds:[assetId],notes:'Original fictional adult Indian model, approved by the studio owner. Preserve face, warm medium skin tone, hairline, body proportions and natural skin texture. Approved ethnicwear makeup: softly winged eyeliner, bronze-gold eyelids, warm blush and rosewood lips. Change clothing to match the original garment references exactly.',createdAt:at});
 for(const c of s.campaigns){if(c.modelId)continue;const hasReviewedWork=s.approvals.some(a=>a.campaignId===c.id)||s.assets.some(a=>a.campaignId===c.id&&a.kind==='image');if(hasReviewedWork)continue;c.modelId=BUILTIN_MODEL_ID;}
}
