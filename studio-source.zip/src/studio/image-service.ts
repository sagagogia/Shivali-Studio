import {getOpenAIStatus,generateOpenAIImage} from './openai.ts';
import {getProviderStatus,generateReferenceImage} from './provider.ts';
export function imageServiceStatus(){if(process.env.SHIVALI_IMAGE_PROVIDER==='fal')return {...getProviderStatus(),provider:'fal' as const};return {...getOpenAIStatus(),provider:'openai' as const};}
export async function generateStudioImage(input:Parameters<typeof generateReferenceImage>[0]){if(imageServiceStatus().provider==='openai')return generateOpenAIImage(input);return generateReferenceImage(input);}
