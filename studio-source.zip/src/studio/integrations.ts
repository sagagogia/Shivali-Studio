import { existsSync } from 'node:fs';
import { join } from 'node:path';
import type { Integration } from './types.ts';
import { imageServiceStatus } from './image-service.ts';
import { getOpenAIStatus } from './openai.ts';
import { getMotionStatus } from './motion.ts';
export function integrations():Integration[]{
 const root=process.env.SHIVALI_OPENMONTAGE_ROOT||'/workspace/scratch/openmontage-inspection-_5ol60ly/OpenMontage';
 const montage=existsSync(join(root,'.venv/bin/python'))&&existsSync(join(root,'tools/video/video_stitch.py'));
 const image=imageServiceStatus(),ai=getOpenAIStatus(),motion=getMotionStatus();
 return [
  {id:'records',name:'Private production records',status:'ready',detail:'SQLite on local disk. Assets are served privately from the studio, not public cloud URLs.'},
  {id:'openmontage',name:'OpenMontage',status:montage?'ready':'not_configured',detail:montage?'Local source-image preview worker installed. 27 seconds, 1080 × 1920.':'Set SHIVALI_OPENMONTAGE_ROOT to a compatible installed checkout.'},
  {id:'image',name:image.provider==='openai'?'OpenAI model photography':'Model imagery via fal',status:image.enabled?'ready':'not_configured',configured:image.configured,estimatedCents:image.estimatedCents,detail:image.enabled?'Reference-conditioned photography is connected. Each request requires approval; exact identity and garment fidelity still need human review.':image.configured?'API key detected. Paid generation is disabled until a spending limit is approved.':'Configure OPENAI_API_KEY privately. No request is sent while generation is disabled.'},
  {id:'motion',name:'Kling realistic motion',status:motion.enabled?'ready':'not_configured',configured:motion.configured,estimatedCents:motion.estimatedCents,detail:motion.enabled?'Three approved 9-second image-conditioned motion clips, assembled by OpenMontage.':'Requires FAL_KEY and explicit video-generation approval. OpenAI Videos API is retired.'},
  {id:'higgsfield',name:'OpenHiggsfield model catalog',status:process.env.SHIVALI_ENABLE_ADVANCED_GENERATOR==='true'?'ready':'blocked',detail:'Original generator preserved at /generate. Disabled by default; campaign governance lives in Shivali Studio.'},
  {id:'planning',name:'Creative director and copy desk',status:'ready',detail:'Offline structured drafts from garment specifications. No live LLM or trend inference is claimed.'},
  {id:'research',name:'Garment vision & fashion research',status:ai.enabled?'ready':'not_configured',configured:ai.configured,estimatedCents:ai.researchEstimatedCents,detail:ai.enabled?'OpenAI inspects original photographs and searches permitted public editorial sources. Human garment review remains required.':ai.configured?'API key detected. Paid research is disabled until a spending limit is approved.':'Configure OPENAI_API_KEY privately. No Instagram scraping or fabricated trends.'},
  {id:'music',name:'Music licensing',status:'not_configured',detail:'Upload a track only after verifying commercial, social and advertising rights. The studio does not grant music rights.'},
  {id:'publishing',name:'Instagram publishing',status:'blocked',detail:'Export for human handoff only. Nothing is published automatically.'}
 ];
}
