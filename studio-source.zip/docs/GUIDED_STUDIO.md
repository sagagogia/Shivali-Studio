# Guided fashion shoots

The homepage now follows **Upload design → Choose shoot → Approve photos → Approve video → Download**. The previous dashboard remains under **Studio details**.

## Available in this update

- One form creates one design and its shoot. Select up to 12 original photographs together; each file keeps the existing 25 MB upload limit. Partial failures retain successful files and let you retry failures only.
- Inline product brief from supplied specifications. Unverified garment details are explicit. Supplied research sources show links, notes and when they were recorded; the application does not fetch arbitrary links.
- Three editorial shoot ideas and explicit concept selection.
- Roster of up to five models, each backed by privately uploaded, approved identity references. Model references are separate from garment originals and shoot outputs. The model sheet approved in chat must be uploaded here; chat files are not automatically in the Render service.
- Three output roles: full pose, close-up and mood. Each has an individual garment review and model-identity confirmation. Replacing one photo retains the other reviewed photos and preserves old versions in history.
- If fal is privately configured and paid generation explicitly enabled, each shot can make one separately approved reference-conditioned image request. Identity references come first, garment originals follow, and the shot role determines framing. Provider cost is an estimate. No provider call was made while developing this update.
- Script/text/caption editing, timed opening/on-screen text rendered into the preview, and 27-second 1080×1920 OpenMontage still-image previews. Complete preview approval unlocks download. Changes require new approvals and a new preview. Older previews are marked outdated. Upload retries carry stable operation IDs so a lost response does not duplicate a committed original. Rejected-shot corrections are passed to regeneration while preserving fixed identity and garment constraints. Selecting a fixed model on an earlier campaign adopts the guided three-photo review rules.

## Still unavailable

Automated vision-based product understanding, live trend research, model motion generation, voice-over generation, automatic licensed-music selection and automatic publishing are not connected. The interface states this explicitly. Source-image previews are labelled still-based. The reference-conditioned image adapter does not guarantee exact model identity or garment accuracy; human review is required.

## Validation

Use `npm test`, `npm run typecheck`, `npm run build`, `node scripts/smoke-auth.mjs`, `node scripts/smoke-guided.mjs` and `node scripts/smoke-studio.mjs`. Browser scripts use temporary private databases, synthetic image fixtures and local Chromium; no garment approval is recorded in the real workspace and no paid provider is called. Do not run two copies of the same smoke script simultaneously: they intentionally use fixed local ports.

## Mobile deployment handoff

The existing GitHub root Dockerfile builds exclusively from `studio-source.zip`. Updating loose root source files does not update that image. Replace only `studio-source.zip` at the GitHub repository root with the new verified archive, then deploy the new commit to the existing **shivali-studio-codex** staging service. Do not create another paid service or change **shivali-studio** production. Keep the current external Dockerfile and the Render-validated root render.yaml. Do not include private data, secrets, model reference uploads or dependencies in the source archive.
