# Guided fashion shoots

**Upload design → Choose shoot → Approve photos → Approve video → Download.** The previous workspace remains under Studio details.

## Fixed model

The approved original adult fictional Model 01 and her ethnicwear makeup reference sheet are included with the source. The server copies this reference to private storage and selects it for new/pristine shoots. No model upload is required. Existing reviewed legacy campaigns retain their photographs, versions and approvals until you explicitly select a fixed model or run new research. Up to five models can be registered; no celebrity likeness or voice clone is required.

## Connected implementation

- Upload multiple original garment photographs for one design. Successes remain saved if another file fails. Stable upload IDs prevent duplicates after a lost response.
- OpenAI reads the actual original photographs, separates observations from uncertainties, researches permitted public editorial references and returns three shoot concepts with scripts, text, captions and music direction. Citations retain source URLs and retrieval date. A source citation does not confer a licence to reuse its images/music or establish Instagram popularity.
- OpenAI GPT Image 2.5 Sunburst edits reference images into full-pose, close-up and mood photographs. Model identity references and garment originals have separate roles. Generate missing photos together or regenerate one with its requested corrections.
- Generated photographs receive local decode checks and an OpenAI garment/identity audit. AI faults block approval until corrected; uncertain findings require careful human review. No AI assessment guarantees exact garment or identity preservation. Each photograph still needs human approval.
- Optional fal Kling3 Pro creates three nine-second motion clips from approved images. OpenMontage assembles a 27-second 1080×1920 H264 Reel and burns in opening/on-screen text. The current motion workflow is cinematic/voice-over B-roll; talking-head lip sync and multi-outfit try-on transformations are not implemented.
- Optional fal ElevenLabs v3 narrates the approved original script in a stock synthetic voice. No celebrity voice cloning. Narration is padded with silence rather than repeated. The app and download caption disclose AI voice-over. Music must have verified commercial rights; automatic trending-audio licensing and publishing are not implemented.
- The complete video requires human approval before final download. Revisions invalidate downstream approvals. Older previews are explicitly marked outdated.

## Credentials and activation

The user saved OPENAI_API_KEY privately in Render. Do not retrieve or print its value. The new code must be deployed before it can use that key. Enabling SHIVALI_ENABLE_PAID_GENERATION=true enables cost-confirmed research and image requests; it does not itself send any paid call. Video/narration also require a privately configured FAL_KEY and SHIVALI_ENABLE_VIDEO_GENERATION=true. The video provider is separate because OpenAI's Videos API was retired September24,2026. Never copy keys into chat, GitHub, the source archive or the browser.

Model availability, API billing, organization verification and actual output quality have not been verified with a live call. Errors surface safe account/quota/access guidance, never provider raw bodies or credentials. A failed/unknown charged request is not retried automatically. Known provider IDs are saved before output validation, and uncertain reservations survive failures/restarts.

## Planning costs

Planning reservations: $0.50 per research pass, $1.00 per generated/audited photograph, $3.30 for a three-clip Reel, $0.10 for optional narration. This totals $6.90 for one pass with three photographs, motion and narration. These are planning allowances, not fixed provider prices or hard billing caps. OpenAI bills usage; fal currently lists Kling Pro at $0.112/second without native audio, and ElevenLabs v3 at $0.10/1000 characters. Provider invoices are authoritative. Retries/new concepts add cost. New guided designs default to a $10 planning limit; previous campaign limits remain unchanged and can be edited under History, budget & connections. Each paid action requires explicit confirmation before submission.

Official references verified November2,2026:

- https://developers.openai.com/api/docs/guides/image-generation
- https://developers.openai.com/api/docs/guides/video-generation
- https://developers.openai.com/api/docs/pricing
- https://developers.openai.com/api/docs/guides/tools-web-search
- https://fal.ai/models/fal-ai/kling-video/v3/pro/image-to-video/llms.txt
- https://fal.ai/models/fal-ai/elevenlabs/tts/eleven-v3/llms.txt

## Validation and release

Run npm test, npm run typecheck, npm run build, scripts/smoke-ai-pipeline.mjs, scripts/smoke-guided.mjs, scripts/smoke-auth.mjs and scripts/smoke-studio.mjs. The AI pipeline smoke uses intercepted/mock external responses and genuine local synthetic PNG/MP4/MP3 fixtures, then executes real OpenMontage composition. No live provider credentials or paid assets are used. Fixtures and approvals stay in temporary private databases. Do not run two copies of the same fixed-port smoke script simultaneously. Hosted rendering capacity on the 512MB staging plan still needs verification with the user's approved job; do not auto-upgrade.

The existing public GitHub repository builds only from root studio-source.zip. Replace that one file with the release archive, verify its hash, then deploy the existing shivali-studio-codex staging service. No extra paid Render service is required. The archive includes only source and the approved synthetic model reference; it excludes secrets, garment uploads, databases and dependencies. Do not alter shivali-studio production.

## Refined workspace interface

The creative studio now has an ivory/forest editorial interface, responsive desktop navigation and a mobile workspace menu. Your designs, Model library, Activity and Settings & connections are backed by actual stored records. Model 01 is available without upload; optional model management remains secondary. The sign-in page uses the same brand system without changing authentication behavior.

Uploads support multiple selected thumbnails and drag/drop. Failed files retain their original campaign ID, and browser history cannot transfer a retry into another design. File previews clear with the native input lifecycle. Photograph reviews are focused, expandable controls; technical setup and history stay in secondary panels. Generation consent uses a branded accessible dialog; cancel, Escape and browser history cancel unsubmitted consent. Estimates remain separate from billing caps. Shared status/errors remain visible on all workspace panels.

Validation also includes scripts/smoke-interface.mjs and scripts/smoke-upload-ownership.mjs for consent/navigation/feedback and cross-design retry isolation. No new cloud services, packages or paid assets were used in this visual update.
