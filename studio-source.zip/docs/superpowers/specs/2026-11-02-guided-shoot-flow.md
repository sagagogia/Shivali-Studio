# Guided Shivali shoot workflow

The user has selected a single guided workflow: Upload design → Choose shoot → Approve photos → Approve video → Download. Research happens between the visible steps, without requiring the user to operate separate research screens. Keep current production unchanged and prepare changes in the isolated development checkout.

## Experience

1. Upload design: select multiple original photos for ONE design together, enter design number, fabric, colour and included accessories. Preserve originals. Allow adding missing references later. Create the garment and its campaign from one intake, without a separate campaign form.
2. Choose shoot: product researcher analyses the available views and identifies neckline, embroidery, fabric, silhouette and accessories, distinguishing observations from uncertain details. Trend researcher collects dated, permitted fashion and video-format evidence with links. Creative director combines both into 2–3 concept cards with setting, lighting, styling, model, suggested video format and reasons. Missing research connections must display unavailable, never simulated completion. Use Model 01's approved natural identity and ethnicwear makeup references, once imported privately into the app. User selects a concept before paid imagery begins.
3. Approve photos: generate one full pose, one close-up and one mood photograph using the same model and approved concept. Show the original garment alongside each result. Per-photo approval or a specific revision request. Technical quality, identity consistency and garment fidelity are separate checks. Any visible fault prevents progression; machine checks do not guarantee exact fidelity and human approval remains required. Preserve approved images when regenerating a rejected image.
4. Approve video: format researcher recommends cinematic montage, UGC-style, influencer or get-ready-with-me only when supported by evidence and available inputs. Scriptwriter prepares narration, shot sequence, captions and on-screen text. Obtain approval for any extra shots/transformations. A video provider creates real motion from approved stills; OpenMontage assembles a 25–28-second, 9:16 preview with licensed audio or an authorised synthetic voice. User watches and approves or requests changes. Do not describe a source-image slideshow as realistic generated video.
5. Download: approved final Reel, cover, caption and hashtags. No automatic publication. Approval and cost history stays available in a secondary details panel.

## Constraints

- The five main step labels are exactly: Upload design, Choose shoot, Approve photos, Approve video, Download.
- Research appears as inline progress/results, with findings and source links available on demand.
- Model 01's approved makeup sheet is a proposed reusable reference, not yet imported or guaranteed consistent by the current app. Keep identity references separate from product originals.
- No paid calls during development. Keep paid generation disabled on staging until separately configured and authorised.
- Preserve persistent assets, version-aware approvals, origin checks, authentication, bounded uploads and budget reservations.
- Revisions invalidate downstream approvals; outdated render outputs cannot be downloaded as the approved final.
- Clearly distinguish planned features from available integrations. Show costs before paid work.

## Approach

Use a guided interface over the existing Next.js studio and durable campaign store. This preserves the existing security and approval foundation. Relabelling the current dashboard alone does not implement researchers or generation. A separate new app would duplicate the working foundation and data, so it is not recommended.

Deliver first the guided interface and multi-photo intake, then evidence-backed researchers, then fixed-model three-shot generation and per-photo review, then realistic video. Each stage has an explicit available/unavailable state. The user should not have to manage agents, provider names or job IDs.
