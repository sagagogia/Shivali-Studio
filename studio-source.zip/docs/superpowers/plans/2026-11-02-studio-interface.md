# Shivali Studio Interface Implementation Plan

> **For agentic workers:** Execute inline using executing-plans; one independent final review.

**Goal:** Refine the existing approved five-step workflow into a polished luxury fashion production app, with useful desktop navigation and an equally complete mobile experience.
**Architecture:** Preserve existing API routes, approvals, budgets, provider gates, fixed identity references and job polling. Add reusable accessible dialogs and a real workspace navigation around the existing stage controller. Use only actual assets and production records. Keep settings/history out of the main shoot flow.
**Tech Stack:** Existing React/Next/TypeScript/CSS/system fonts, no dependencies or paid assets.
**Spec:** User delegates visual decisions, prioritises luxury realism and simple Upload design → Choose shoot → Approve photos → Approve video → Download; approved model already built in. No new credential or paid-call authorisation required for local UI development.

## Constraints and review focus
- Warm ivory, deep forest, muted champagne; existing wordmark serif and readable system body type. Colour/font tokens; reduced motion and keyboard focus visible.
- No invented campaign imagery, metrics, sources, testimonials or ready states. Original garment images and approved fictional identity clearly distinguished.
- Usable at390px, no global horizontal overflow, primary action easy to find; 44px minimum tap targets.
- Accessible dialogs for paid-operation consent: no request before explicit approval; cancel/Escape means no paid request. Clear estimate/invoice distinction remains.
- Real design library, model management, activity and settings panels; no decorative dead navigation.
- Preserve all original file uploads, retry IDs, role/identity reviews, stale-version checks, export and settings functionality.
- Preserve approval semantics and disabled-state explanations. No accidental automatic generation, publishing or credentials in client code.

## Tasks
- [x] Add reusable dialog and workspace navigation/chrome with mobile menu.
- [x] Refine stage hierarchy, image gallery, fixed-model context, source/technical details, library/models/activity/settings; keep mutations wired.
- [x] Add visual multi-file selection and drag/drop, branded paid-operation confirmation and caption-copy feedback.
- [x] Rework CSS for responsive luxury workspace, explicit empty/loading/error/pending/approved states.
- [x] Verify66+ unit tests, typecheck/build, updated guided mobile/browser scenarios, auth and existing provider/render pipeline fixtures. Fresh review then one fix pass. Package one source ZIP; staging remains unchanged until uploaded source verified.

Implementation and local verification complete. Live staging update pending user upload of the verified source archive; existing provider activation requirements remain.
