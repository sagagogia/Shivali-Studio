# Shivali Studio Implementation Plan

Goal: ship a durable local fashion-marketing workflow using the installed repositories.
Architecture: Next.js studio backed by SQLite and private disk storage; typed API; OpenMontage worker for local source-image previews; fal-ready provider requests with no paid calls during development.
Tech stack: Node 24, Next 16, React 19, SQLite, Python 3.12, FFmpeg, OpenMontage.
Spec: ../specs/2026-11-02-shivali-studio.md

Global constraints: local-only; no paid calls or credential changes; preserve original checkouts; integer-cent budgets; exact garment fidelity is human-reviewed; source-image previews are not motion generation.

Review focus: stale approvals; malicious uploads and paths; duplicate cost reservations; jobs surviving restart/failure; exports without final approval.

- [x] Task 1: Core state and API. src/studio/core.ts, store.ts, types.ts; src/app/api/studio/**; tests/core.test.ts. SQLite transactions, upload validation, versioned approval gates, immutable audit events, source evidence, export bundles. Verify node --experimental-strip-types --test tests/core.test.ts.
- [x] Task 2: Marketing workbench. src/studio/Studio.tsx, studio.css, tokens.css; root page; tests via production build + browser. Intake, campaigns, plans, asset QA, budgets, source research, approval queue, export, batch campaign creation, truthful integrations and empty/error states.
- [x] Task 3: OpenMontage worker. src/studio/render.ts, scripts/openmontage_render.py, tests/render.test.ts. Restricted local tools, render packets, ffprobe verification, bounded subprocess execution and restart-visible jobs. Verify offline fixture render and adapter tests.
- [x] Task 4: Provider request bridge. src/studio/provider.ts and tests/provider.test.ts. Explicit fal model route, reference conditioning, per-call approval/budget reservation, timeouts, safe result URL handling; no real calls in tests.
- [x] Task 5: Integrate, review, run full tests, typecheck, build, browser QA, fix important findings, document limitations. Preserve tested local server for handoff.
