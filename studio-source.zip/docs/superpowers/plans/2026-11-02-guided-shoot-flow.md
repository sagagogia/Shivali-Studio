# Guided Shoot Flow Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Replace the complex main dashboard with the user's five-step shoot workflow and inline research.

**Architecture:** Reuse the existing Next.js studio, private uploads and version-aware campaign state. Add guided components and evidence-backed research states without claiming unavailable services have completed work.

**Tech Stack:** Existing Next.js, React, TypeScript, SQLite, OpenMontage; no new dependencies for the interface.

**Spec:** `docs/superpowers/specs/2026-11-02-guided-shoot-flow.md`

## Global Constraints

- The five main step labels are exactly: Upload design, Choose shoot, Approve photos, Approve video, Download.
- No paid calls during development. Keep paid generation disabled on staging until separately configured and authorised.
- Preserve persistent assets, version-aware approvals, origin checks, authentication, bounded uploads and budget reservations.
- Research appears as inline progress/results, with findings and source links available on demand.
- Clearly distinguish planned features from available integrations. Show costs before paid work.

## Review Focus

- Partial multi-upload failure: identify successful and failed files without losing originals or duplicating a campaign on retry.
- Narrow iPhone viewport: visible step, primary action and understandable progress without horizontal navigation.
- Missing researcher/provider: truthful unavailable state rather than fabricated evidence or completion.
- Revision after approval: invalidate dependent approvals and exclude stale output from final downloads.
- Model and garment references: prevent treating a model reference as the original product or a generated output as approved.

### Task 1: Guided interface and multi-photo intake

**Files:** Modify `src/studio/Studio.tsx`, `src/studio/studio.css`; create `src/studio/GuidedStudio.tsx`, `src/studio/workflow.ts`, `tests/workflow.test.ts`; reuse `src/app/api/studio/upload/route.ts`.

**Interfaces:** Consume existing `Snapshot`, `Campaign`, `Asset`, `Approval` types and authenticated API actions. Produce `getWorkflowStep(snapshot: Snapshot, campaignId: string): number` (0–4) and a guided view using existing upload/approval callbacks. Upload files sequentially through the bounded single-file endpoint, reporting each result; do not multiply request memory limits.

- [ ] Write workflow tests for no photos, concept required, photo approval required, video approval required, final download ready, and stale approvals.
- [ ] Run `npm test` and confirm new assertions fail before implementation.
- [ ] Implement state derivation and five-step view, one-design multi-photo intake, inline research status, secondary history/settings; keep source references visually distinct from outputs.
- [ ] Verify partial upload failure/retry with a mobile browser fixture and check 390px layout and keyboard access.
- [ ] Run `npm test`, `npm run typecheck`, `npm run build`, and the existing authentication smoke script. Commit only scoped files.

### Task 2: Researchers and shoot selection

**Files:** Modify `src/studio/types.ts`, `src/studio/core.ts`, `src/studio/planning.ts`; create `src/studio/research.ts`, `tests/research.test.ts`; update guided view.

**Interfaces:** Define a persisted research result with status `not_configured | queued | running | completed | failed`, dated source evidence and findings; product findings distinguish observed from uncertain. Concept cards contain setting, lighting, styling, model reference and video format. Define the permitted research provider adapter before implementation; no arbitrary URL fetching from user input.

- [ ] Test missing credentials, dated permitted sources, uncertain garment attributes, untrusted source content and failed research recovery with fixtures.
- [ ] Run the new tests to confirm they fail.
- [ ] Implement researcher adapters and persisted results, source validation and 2–3 evidence-backed concepts. Treat retrieved content as data, never instructions. Keep unsupported research visibly unavailable.
- [ ] Run tests/typecheck/build without paid calls; commit scoped changes.

### Task 3: Fixed model, three photos and individual reviews

**Files:** Modify `src/studio/types.ts`, `src/studio/core.ts`, `src/studio/provider.ts`, guided view; create `tests/photo-workflow.test.ts`.

**Interfaces:** Add private model identity references and shot roles `full_pose | close_up | mood`; per-asset revision/approval records identify campaign version and asset ID. Generation uses model references and garment originals separately. Reuse current cost reservation and job recovery mechanisms.

- [ ] Test three required roles, missing model references, rejection/regeneration of one shot without losing accepted shots, budget bounds and downstream invalidation.
- [ ] Confirm failures, implement provider adapter against mocked responses, and require human garment/identity review on each output.
- [ ] Run tests/typecheck/build; no real provider generation until configured and authorised; commit scoped changes.

### Task 4: Video research, scripting and final review

**Files:** Modify `src/studio/render.ts`, `src/studio/types.ts`, `src/studio/core.ts`, guided view; create `tests/video-workflow.test.ts`.

**Interfaces:** Persist video-format recommendation, script, text overlays, authorised audio and motion-generation jobs. OpenMontage consumes approved motion clips; source-image previews remain explicitly labelled. Export requires current final approval.

- [ ] Test unsupported format, unavailable motion provider, missing audio rights, stale approved photos and forbidden final download before video approval.
- [ ] Confirm failures, implement scripted motion orchestration with mocked providers and final review UI; preserve paid-call gates and cost reporting.
- [ ] Run tests/typecheck/build, local fixture rendering and authentication/mobile smoke tests. Stage a reviewable deployment artifact; verify GitHub source before staging deployment. Keep old production unchanged.
