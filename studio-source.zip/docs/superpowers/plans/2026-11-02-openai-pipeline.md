# OpenAI Pipeline Implementation Plan

> **For agentic workers:** Use superpowers:executing-plans inline, with test-driven-development and one fresh final review.

**Goal:** Make the approved fictional model built in and wire garment vision/research, reference-conditioned photography and real-motion orchestration behind the existing five-step workflow.
**Architecture:** Reuse the isolated studio, private durable files, version-aware approvals and pre-submission cost reservations. All external calls require configuration, explicit user approval and budget; no paid test calls. OpenAI image editing and Responses API run server-side. OpenAI Videos API is retired; optional fal Kling motion clips feed the audited local OpenMontage assembler.
**Tech Stack:** Existing Node24/Next/React/TypeScript/Python/FFmpeg; native fetch/FormData, no new packages.
**Spec:** Existing guided-shoot-flow specification plus user's requests for built-in approved model, automatic product analysis and working image/video generation. User selected OpenAI by creating and saving OPENAI_API_KEY in Render; no secret is read back.

## Global constraints
- Preserve production, secrets, garment originals, approval/version checks, bounded IO, exclusive writes and provider uncertainty on restart.
- No live paid calls until a spending limit is approved. Estimate reservations are not provider billing caps.
- Model 01's approved reference sheet is bundled; uploaded garment photos and secrets are never bundled.
- No fabrication of trend sources or claims of exact garment/identity preservation.
- No retired Sora endpoints. No automatic retry of possibly charged submissions.

## Review focus
- Built-in seeding idempotent with existing state and user-approved custom models.
- Missing keys/feature flags block before any request; errors never expose credentials/provider raw bodies.
- Generated output, sources and AI analysis are untrusted bounded data.
- Changed or rejected upstream versions cannot complete paid jobs or release final output.
- Partial batch/worker restart preserves provider IDs and uncertain budget reservations.

## Tasks
- [x] Built-in model: copy approved synthetic sheet into assets/models, seed private identity asset/profile idempotently, select for unassigned campaigns. Hide roster upload behind optional settings. Test seed/migration and existing data preservation.
- [x] OpenAI adapter: bounded fixed-origin transport, images/edits reference identity+garment, validated base64 PNG and exclusive writes; Responses multimodal/web search plus strict schema, source citations and safe errors; mocked tests cover missing auth, failed/refused/malformed responses, uncertainty, no URL key leakage. Default editing model follows current official docs, editing precision (gpt-image-2.5-sunburst).
- [x] Research/image integration: persisted vision observations, uncertainty, cited sources, 3 concepts/scripts, pre-submit reservations and guided UI progress/cost approval; existing image provider fallback remains explicit. Do not silently invoke another provider or cheaper model.
- [x] Video pipeline: fal Kling3 Pro image-to-video adapter with 9-second clips, explicit cost consent, current photo references, durable IDs, bounded media, retained uncertain reservations; local OpenMontage composition of 3 clips to27s with text. Human final approval; unavailable until FAL_KEY and feature flag configured.
- [x] Verify all unit/type/build, local mobile/auth/source/motion fixtures. Independent review, one fix pass, source ZIP without secrets/garment uploads, then staging handoff.

Release state: implementation and local verification complete; user upload required because GitHub integration denies writes. Hosted activation is pending that verified upload and private provider settings. No live API generation performed.
