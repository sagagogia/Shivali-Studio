import assert from 'node:assert/strict';
import {spawn,execFileSync} from 'node:child_process';
import {mkdtemp,readFile,writeFile,rm,mkdir} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import path from 'node:path';
import puppeteer from 'puppeteer-core';
const dir=await mkdtemp(path.join(tmpdir(),'shivali-guided-browser-'));
const base='http://127.0.0.1:3022';let logs='';let browser;
const server=spawn(process.execPath,['node_modules/next/dist/bin/next','start','--hostname','127.0.0.1','--port','3022'],{env:{...process.env,SHIVALI_DATA_DIR:dir,SHIVALI_ENABLE_PAID_GENERATION:'false',SHIVALI_ENABLE_ADVANCED_GENERATOR:'false',NEXT_TELEMETRY_DISABLED:'1'},stdio:['ignore','pipe','pipe']});
server.stdout.on('data',b=>logs+=b);server.stderr.on('data',b=>logs+=b);
const pause=ms=>new Promise(r=>setTimeout(r,ms));
try{
 for(let i=0;i<100;i++){try{if((await fetch(base)).ok)break;}catch{}if(server.exitCode!==null)throw Error(logs);await pause(100);}
 const fixture=path.join(dir,'fixture.png'),bad=path.join(dir,'bad.png');execFileSync('ffmpeg',['-v','error','-f','lavfi','-i','color=c=0x436a74:s=180x320','-frames:v','1','-threads','1',fixture]);await writeFile(bad,'Invalid image fixture');
 browser=await puppeteer.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});const page=await browser.newPage();await page.setViewport({width:390,height:844});const errors=[];page.on('pageerror',e=>errors.push(e.message));let paidRequests=0;page.on('request',r=>{if(r.url().includes('/api/studio/generate'))paidRequests++;});
 await page.goto(base,{waitUntil:'networkidle0'});await page.waitForSelector('.guided-heading');
 async function clickText(text){await page.waitForFunction(text=>[...document.querySelectorAll('button')].some(x=>x.textContent.trim()===text&&!x.disabled),{},text);await page.evaluate(text=>[...document.querySelectorAll('button')].find(x=>x.textContent.trim()===text).click(),text);}
 async function ready(){await page.waitForFunction(()=>document.querySelector('.guided-panel')?.getAttribute('aria-busy')==='false');}
 async function snapshot(){return (await fetch(`${base}/api/studio`)).json();}
 async function step(n){await page.waitForFunction(n=>document.querySelector('.guided-mobile-progress')?.textContent.startsWith(`Step ${n} of`),{},n);}
 await clickText('New design');await page.type('[name=designNumber]','BROWSER-TEST');await page.type('[name=fabric]','Silk');await page.type('[name=color]','Metallic blue');await page.click('[name=dupatta]');await (await page.$('[name=photos]')).uploadFile(fixture,bad);await clickText('Save design & photographs');await ready();
 let s=await snapshot();const c=s.campaigns.find(x=>x.title==='BROWSER-TEST · Shoot');assert.ok(c);assert.equal(s.campaigns.length,2);assert.equal(s.assets.filter(a=>a.campaignId===c.id&&a.kind==='reference').length,1);assert.ok((await page.content()).includes('bad.png'));
 await clickText('Retry only failed photographs');await ready();s=await snapshot();assert.equal(s.campaigns.length,2);assert.equal(s.assets.filter(a=>a.campaignId===c.id).length,1);
 // Simulate the server committing an upload but its response being lost in transit.
 await page.evaluate(()=>{const original=window.fetch;let dropped=false;window.fetch=async(...args)=>{const response=await original(...args);if(!dropped&&String(args[0]).endsWith('/api/studio/upload')){dropped=true;throw Error('Synthetic response lost after commit');}return response;};});
 await (await page.$('[name=photos]')).uploadFile(fixture);await clickText('Add photographs');await ready();s=await snapshot();assert.equal(s.assets.filter(a=>a.campaignId===c.id&&a.kind==='reference').length,2);const uploadVersion=s.campaigns.find(x=>x.id===c.id).version;
 await clickText('Retry only failed photographs');await ready();await step(2);s=await snapshot();assert.equal(s.assets.filter(a=>a.campaignId===c.id&&a.kind==='reference').length,2);assert.equal(s.campaigns.find(x=>x.id===c.id).version,uploadVersion);
 assert.ok((await page.content()).includes('Analyse garment &amp; research shoots'));assert.equal((await snapshot()).campaigns.find(x=>x.id===c.id).modelId,'shivali-model-01');assert.ok((await page.content()).includes('Model 01'));
 await clickText('Prepare offline shoot ideas');await ready();assert.equal((await page.$$('.guided-concept')).length,3);await page.click('.guided-concept');await ready();await clickText('Approve concept & continue');await ready();await step(3);
 await page.click('details:has(input[name=shot]) > summary');
 for(let i=0;i<3;i++){const role=['full_pose','close_up','mood'][i];await page.select('form:has(input[name=shot]) select',role);await (await page.$('[name=shot]')).uploadFile(fixture);await clickText('Add / replace photograph');await ready();const selector=`.guided-photo:nth-child(${i+1})`;await page.click(`${selector} .photo-review-controls > summary`);await page.waitForSelector(`${selector} textarea`,{visible:true});await page.type(`${selector} textarea`,'Synthetic fixture only: testing review workflow, not approving a real garment.');await page.click(`${selector} input[name=identity]`);await page.click(`${selector} form button`);await ready();}
 await clickText('Approve photos & continue');await ready();await step(4);assert.ok((await page.content()).includes('Video connection required'));
 assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),'iPhone layout must not overflow');
 await mkdir('artifacts',{recursive:true});await page.screenshot({path:'artifacts/qa-guided-mobile.png',fullPage:true});
 await clickText('Create still-image preview');await ready();
 for(let i=0;i<120;i++){s=await snapshot();const j=s.jobs.find(j=>j.campaignId===c.id&&j.kind==='render');if(j?.status==='completed')break;if(j?.status==='failed')throw Error(j.message);if(i===119)throw Error('Render timeout');await pause(500);}
 await clickText('Approve preview & continue');await ready();await step(5);await page.waitForSelector('a[download]');assert.ok((await page.content()).includes('Download approved preview'));
 const packet=await fetch(`${base}/api/studio/export/${c.id}`);assert.equal(packet.status,200);const exported=await packet.json();assert.equal(exported.campaign.status,'exported');assert.equal(exported.assets.filter(a=>a.kind==='image'&&!a.superseded).length,3);
 // A script revision must make the existing preview unavailable as a final download.
 const res=await fetch(`${base}/api/studio`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({type:'campaign.copy',campaignId:c.id,caption:'Changed fixture caption'})});assert.equal(res.status,200);assert.equal((await fetch(`${base}/api/studio/export/${c.id}`)).status,409);
 assert.equal(errors.length,0,errors.join('\n'));assert.equal(paidRequests,0);
 const report={passed:true,paidCalls:0,checks:['one-form design intake','multi-photo upload','partial failure preserves successful originals','retry does not duplicate design or files','lost response after committed upload retries idempotently','separate approved model references','three selectable concepts','individual full/close/mood review','identity confirmation','version-aware approvals','OpenMontage still preview','final approval download','script revision revokes export','390px mobile layout','no browser exceptions'],fixture:'Synthetic image in a temporary private database; no real garment approvals.'};await writeFile('artifacts/guided-smoke-report.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
} catch(e){await mkdir('artifacts',{recursive:true});await writeFile('artifacts/guided-smoke-server.log',logs);if(browser){const pages=await browser.pages();await pages.at(-1).screenshot({path:'artifacts/guided-smoke-failure.png',fullPage:true});}throw e;}
finally{if(browser)await browser.close();server.kill('SIGTERM');await new Promise(r=>server.once('exit',r));await rm(dir,{recursive:true,force:true});}
