import test from 'node:test';
import assert from 'node:assert/strict';
import {previewOverlays} from '../src/studio/workflow.ts';
test('opening and edited on-screen text become timed 27-second preview overlays',()=>{const overlays=previewOverlays({hook:'Handcrafted silk',onScreenText:['Exact neckline','Discover the collection']} as never);assert.equal(overlays[0].text,'Handcrafted silk');assert.equal(overlays[0].startSeconds,0);assert.equal(overlays.at(-1)!.endSeconds,27);assert.ok(overlays.some(x=>x.text==='Exact neckline'));assert.deepEqual(previewOverlays(null),[]);});
