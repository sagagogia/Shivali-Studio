import test from 'node:test';
import assert from 'node:assert/strict';
import {buildFixedModelPrompt} from '../src/studio/provider.ts';
const garment={designNumber:'D1',fabric:'silk',color:'blue',includesNecklace:true,includesDupatta:true,notes:'Exact embroidery'};
test('fixed model shot prompts distinguish identity from garment references and frame each role',()=>{for(const role of ['full_pose','close_up','mood'] as const){const p=buildFixedModelPrompt(garment,'Luxury studio',role,1,'Warm skin and approved makeup');assert.match(p,/same adult model/i);assert.match(p,/first 1 image/i);assert.match(p,/remaining images/i);assert.match(p,/skin texture/i);assert.match(p,/embroidery/i);assert.match(p,role==='full_pose'?/head.to.toe/i:role==='close_up'?/close.up/i:/mood/i);}assert.throws(()=>buildFixedModelPrompt(garment,'Studio','wrong' as 'mood',1,''),/shot/i);});
test('requested corrections are included without overriding model and garment constraints',()=>{const p=buildFixedModelPrompt(garment,'Studio','close_up',1,'Approved features','Restore missing neckline embroidery.');assert.match(p,/Restore missing neckline embroidery/);assert.match(p,/must not override/i);});
